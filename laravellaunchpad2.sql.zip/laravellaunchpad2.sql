-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 18, 2021 at 12:30 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravellaunchpad2`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2016_06_01_000001_create_oauth_auth_codes_table', 2),
(6, '2016_06_01_000002_create_oauth_access_tokens_table', 2),
(7, '2016_06_01_000003_create_oauth_refresh_tokens_table', 2),
(8, '2016_06_01_000004_create_oauth_clients_table', 2),
(9, '2016_06_01_000005_create_oauth_personal_access_clients_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('349b3449c03e097b5063a4d19ca6a9b3853631ee01ba02be11b51bb852ace1ec5ac5ee54ba2d7f88', 1, 1, 'MyApp', '[]', 0, '2021-11-09 07:35:56', '2021-11-09 07:35:56', '2022-11-09 13:05:56'),
('557dd9fd8fdecf671b31a0ec3be8ebf5e805558853a8d3f4e90aacf48d51f1fc94919bea9db134cb', 1, 1, 'MyApp', '[]', 0, '2021-11-09 08:24:19', '2021-11-09 08:24:19', '2022-11-09 13:54:19'),
('635e6870edabb46d7abc75e3923aa31898e34d777852d930a44e53eee9a84a6ebd1512326e802949', 1, 1, 'MyApp', '[]', 0, '2021-11-08 07:54:10', '2021-11-08 07:54:10', '2022-11-08 13:24:10'),
('6f2b7d286e132d05d6632a8ad8eefecf5aba83382023b9175643a798518588d3b70aefe8daf511de', 4, 1, 'MyApp', '[]', 0, '2021-11-08 07:06:24', '2021-11-08 07:06:24', '2022-11-08 12:36:24'),
('75c46e7a74fd8f755b422b80e1e42e6090aa444c346c73542cbbcfef34936b58dc80f7918b084ffe', 1, 1, 'MyApp', '[]', 0, '2021-11-09 07:51:46', '2021-11-09 07:51:46', '2022-11-09 13:21:46'),
('78cfa33b7762651208371c888d3dc2e97cea7ae02967983a3e465484d09a9babace6d742eb0a21d6', 1, 1, 'MyApp', '[]', 0, '2021-11-09 07:38:35', '2021-11-09 07:38:35', '2022-11-09 13:08:35'),
('7d8797afa11b60a92ed2eadf27897900dae55f98478cd1a2875dca653b32b0c00ceeed3e55804554', 1, 1, 'MyApp', '[]', 0, '2021-11-09 07:43:22', '2021-11-09 07:43:22', '2022-11-09 13:13:22'),
('8542c95b9d3ad31520ae761087f90327e54b93900e0aa0ae79a5e36c4d49b17af402955e2304264a', 1, 1, 'MyApp', '[]', 0, '2021-11-09 07:34:03', '2021-11-09 07:34:03', '2022-11-09 13:04:03'),
('862be5d1cafaa3c8af696d7e5cbffa56bb233d081f3144e249c90279778ce28be71ca1cb518da646', 1, 1, 'MyApp', '[]', 0, '2021-11-08 06:48:40', '2021-11-08 06:48:40', '2022-11-08 12:18:40'),
('90e4e1d4ffb2f0eb2e9b7e635ecf68360b2557af656d5a3ad7050d9778c03f78a2b776f0752eb971', 1, 1, 'MyApp', '[]', 0, '2021-11-09 07:43:52', '2021-11-09 07:43:52', '2022-11-09 13:13:52'),
('985e9eb980c0000cf0015fd8821b80e72a3a6355060e7586d5dcb38802f0eb7697f94a96c80d8489', 1, 1, 'MyApp', '[]', 0, '2021-11-09 07:45:44', '2021-11-09 07:45:44', '2022-11-09 13:15:44'),
('a87c53146242a632243447c0eb71260cb6ba61a60674c2ce01173d18bd164d9450361ee2a4cb4424', 1, 1, 'MyApp', '[]', 0, '2021-11-08 23:52:23', '2021-11-08 23:52:23', '2022-11-09 05:22:23'),
('b17dcdadbb731813b0cca79f195ad9be104074bfea576dfc3e809c7268b2d01dd82abc16e5e253d8', 1, 1, 'MyApp', '[]', 0, '2021-11-09 06:55:24', '2021-11-09 06:55:24', '2022-11-09 12:25:24'),
('b1e5cfa99ab485dd6ae153fbea3c9f02560aab645e0130bbf91e919d7fc79187ea1f21e38810a9c9', 1, 1, 'MyApp', '[]', 0, '2021-11-08 05:06:39', '2021-11-08 05:06:39', '2022-11-08 10:36:39'),
('b2de4ab07d36892a82ddc82d4c5385570b7e704926df2edad506050c42ed103ebdd18d15ef1eb975', 1, 1, 'MyApp', '[]', 0, '2021-11-09 08:23:48', '2021-11-09 08:23:48', '2022-11-09 13:53:48'),
('b361c166ada42cdb3a0f4d0add67f69e9467cc2e05849dfac750efabe05155b9e6a88291161c9aff', 1, 1, 'MyApp', '[]', 0, '2021-11-08 03:48:40', '2021-11-08 03:48:40', '2022-11-08 09:18:40'),
('bc270a14eb7cd09cd747665ef840fda5e8d3627358663dfb6cb3ae135c48ce60eee2dabf4a42afa8', 1, 1, 'MyApp', '[]', 0, '2021-11-09 07:38:12', '2021-11-09 07:38:12', '2022-11-09 13:08:12'),
('c1078e8d9e24d0ca9a33568923d9c9cac5758e421faf92a3e90544d46bcc013dddcd60da72b9ea29', 1, 1, 'MyApp', '[]', 0, '2021-11-08 06:46:25', '2021-11-08 06:46:25', '2022-11-08 12:16:25'),
('d3d6c39e1abceb7152bd7620fc08491c230db6eb6bcbae49adb79cbe3f0acc77ff18e9a34f924e6d', 1, 1, 'MyApp', '[]', 0, '2021-11-09 07:35:11', '2021-11-09 07:35:11', '2022-11-09 13:05:11'),
('e111bc75487b08b41b3bb7fa7062bf2385f76b432d7d5ab9168bad51bd9339fe9e62a01b2bd2d9fc', 1, 1, 'MyApp', '[]', 0, '2021-11-09 06:52:16', '2021-11-09 06:52:16', '2022-11-09 12:22:16'),
('e276975b321c604b062bdcc2a18a5f48833c3f32b5da4f8d4782cfa574473f39f9e60afb5ee60b7b', 1, 1, 'MyApp', '[]', 0, '2021-11-08 04:58:45', '2021-11-08 04:58:45', '2022-11-08 10:28:45'),
('f3a5b2281dbe7b30ce151544c951e845ceb72657cb51634b206f3a446d714b2e6ff2e16f0ffee64c', 4, 1, 'MyApp', '[]', 0, '2021-11-08 07:07:36', '2021-11-08 07:07:36', '2022-11-08 12:37:36');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `provider`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Laravel Personal Access Client', 'LZX3hrDkBaICQ3UEAsQoKKS7gqR9T4D2O4Y3Wq1N', NULL, 'http://localhost', 1, 0, 0, '2021-11-08 02:32:14', '2021-11-08 02:32:14'),
(2, NULL, 'Laravel Password Grant Client', 'HnIG7FK3EuXKdZgB6V08d7ch4STrODitMmHgUqWN', 'users', 'http://localhost', 0, 1, 0, '2021-11-08 02:32:14', '2021-11-08 02:32:14');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2021-11-08 02:32:14', '2021-11-08 02:32:14');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `assignedteacher` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flag` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role`, `assignedteacher`, `flag`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'abc', 'abc@gmail.com', NULL, '$2y$10$4TKuUmwV30Ox81OYE/cFo.BIRzoIR4gEdpsQRSVJr5r1mrlXYj4re', 'admin', NULL, '0', NULL, '2021-11-08 03:48:39', '2021-11-08 03:48:39'),
(2, 'poke', 'xyz@gmail.com', NULL, '12345678', 'student', NULL, '0', NULL, '2021-11-08 03:48:39', '2021-11-08 07:02:14'),
(3, 'lmn', 'lmn@gmail.com', NULL, '12345678', 'teacher', NULL, '0', NULL, '2021-11-08 06:51:55', '2021-11-08 06:51:55'),
(4, 'test2', 'test1@gmail.com', NULL, '12345678', 'admin', NULL, '0', NULL, '2021-11-08 07:06:24', '2021-11-08 07:09:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_auth_codes_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
